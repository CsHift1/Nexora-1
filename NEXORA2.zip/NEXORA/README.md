# NEXORA

**A modern data management platform that simplifies how you organize, manage and understand your data.**

NEXORA is a modern data management platform designed to simplify database organization, record management, information retrieval and business analytics through an intuitive interface.

Built with modern web technologies, NEXORA explores practical approaches to data management, visualization and digital business operations.

## Pages

- **Overview** (`index.html`): summary cards and the most recent records
- **Dashboard** (`dashboard.html`): activity chart, top categories and recent activity
- **Data Records** (`records.html`): add, edit, delete, search and filter records
- **Analytics** (`analytics.html`): date-range analytics, category breakdown, insights and CSV export

## Getting started

Open `index.html` in your browser. There is no build step. Your data is saved in your browser's `localStorage`.

## Built with

HTML, CSS and JavaScript. Icons by Font Awesome and the Manrope font from Google Fonts.

## Documentation

- [Project overview](documents/project-overview.md)
- [Features](documents/features.md)
- [Installation](documents/installation.md)
- [Database structure](documents/database-structure.md)
