/* NEXORA · database.js
 * Data layer. Stores everything in the browser's localStorage and exposes
 * it as window.NexoraDB. See documents/database-structure.md.
 */
(function (global) {
    'use strict';

    const KEYS = { records: 'nexora_records', activity: 'nexora_activity', users: 'nexora_users' };
    const LIMITS = { title: 120, category: 40, notes: 500, activity: 50 };
    const DEFAULT_USERS = [{ id: 'usr_admin', name: 'Administrator', role: 'Workspace Owner' }];

    function read(key, fallback) {
        try {
            const raw = localStorage.getItem(key);
            const data = raw ? JSON.parse(raw) : fallback;
            return Array.isArray(data) ? data : fallback;
        } catch (e) {
            return fallback;
        }
    }

    function write(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (e) {
            return false; // storage full or unavailable
        }
    }

    function uid(prefix) {
        return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    }

    function clean(value, max) {
        return String(value == null ? '' : value).trim().slice(0, max);
    }

    function logActivity(action, title) {
        const list = read(KEYS.activity, []);
        list.unshift({ id: uid('act'), action: action, title: title, at: new Date().toISOString() });
        write(KEYS.activity, list.slice(0, LIMITS.activity));
    }

    const NexoraDB = {
        /* All records, newest first. */
        getRecords() {
            return read(KEYS.records, []).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        },

        /* Add a record. Returns the saved record, or null if title/category is empty or saving failed. */
        addRecord(data) {
            const title = clean(data && data.title, LIMITS.title);
            const category = clean(data && data.category, LIMITS.category);
            if (!title || !category) return null;

            const record = {
                id: uid('rec'),
                title: title,
                category: category,
                notes: clean(data.notes, LIMITS.notes),
                createdAt: new Date().toISOString(),
                updatedAt: null
            };
            const records = read(KEYS.records, []);
            records.push(record);
            if (!write(KEYS.records, records)) return null;
            logActivity('added', title);
            return record;
        },

        /* Update a record by id. Returns the updated record, or null. */
        updateRecord(id, data) {
            const records = read(KEYS.records, []);
            const record = records.find((r) => r.id === id);
            const title = clean(data && data.title, LIMITS.title);
            const category = clean(data && data.category, LIMITS.category);
            if (!record || !title || !category) return null;

            record.title = title;
            record.category = category;
            record.notes = clean(data.notes, LIMITS.notes);
            record.updatedAt = new Date().toISOString();
            if (!write(KEYS.records, records)) return null;
            logActivity('updated', title);
            return record;
        },

        /* Delete a record by id. Returns true if a record was removed. */
        deleteRecord(id) {
            const records = read(KEYS.records, []);
            const record = records.find((r) => r.id === id);
            if (!record) return false;
            write(KEYS.records, records.filter((r) => r.id !== id));
            logActivity('deleted', record.title);
            return true;
        },

        /* Sorted list of distinct category names. */
        getCategories() {
            const names = new Set(read(KEYS.records, []).map((r) => r.category));
            return Array.from(names).sort((a, b) => a.localeCompare(b));
        },

        /* Workspace users. A new workspace has one: the Administrator. */
        getUsers() {
            const users = read(KEYS.users, []);
            return users.length ? users : DEFAULT_USERS.slice();
        },

        /* Latest activity entries, newest first. */
        getActivity(limit) {
            return read(KEYS.activity, []).slice(0, limit || LIMITS.activity);
        },

        /* Numbers used by the stat cards. */
        getStats() {
            const records = read(KEYS.records, []);
            const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
            const json = JSON.stringify(records) + JSON.stringify(read(KEYS.activity, []));
            return {
                total: records.length,
                weekly: records.filter((r) => new Date(r.createdAt).getTime() >= weekAgo).length,
                users: NexoraDB.getUsers().length,
                bytes: new Blob([json]).size
            };
        },

        /* Remove all records and activity. */
        clearAll() {
            write(KEYS.records, []);
            write(KEYS.activity, []);
        }
    };

    global.NexoraDB = NexoraDB;
})(window);
