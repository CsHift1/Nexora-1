/* NEXORA · app.js
 * Shared UI logic for index.html, dashboard.html and records.html.
 * Each renderer only runs if its elements exist on the current page.
 * User-entered text is always inserted with textContent, never innerHTML.
 */
(function () {
    'use strict';

    const DB = window.NexoraDB;
    const SVG_NS = 'http://www.w3.org/2000/svg';
    const DAY = 24 * 60 * 60 * 1000;
    const $ = (id) => document.getElementById(id);

    const state = { search: '', category: '', editingId: null };

    /* ---------- helpers ---------- */

    function el(tag, className, text) {
        const node = document.createElement(tag);
        if (className) node.className = className;
        if (text !== undefined) node.textContent = text;
        return node;
    }

    function svgEl(name, attrs, text) {
        const node = document.createElementNS(SVG_NS, name);
        Object.keys(attrs || {}).forEach((k) => node.setAttribute(k, attrs[k]));
        if (text !== undefined) node.textContent = text;
        return node;
    }

    function clear(node) {
        while (node.firstChild) node.removeChild(node.firstChild);
    }

    function formatSize(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    }

    function formatDate(iso) {
        return new Date(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
    }

    function timeAgo(iso) {
        const seconds = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
        if (seconds < 60) return 'Just now';
        if (seconds < 3600) return Math.floor(seconds / 60) + ' min ago';
        if (seconds < 86400) return Math.floor(seconds / 3600) + ' h ago';
        return formatDate(iso);
    }

    function startOfDay(d) {
        return new Date(d.getFullYear(), d.getMonth(), d.getDate());
    }

    function countByCategory(records) {
        const map = {};
        records.forEach((r) => { map[r.category] = (map[r.category] || 0) + 1; });
        return Object.keys(map)
            .map((name) => ({ name: name, count: map[name] }))
            .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
    }

    /* ---------- stat cards (index, dashboard) ---------- */

    function renderStats() {
        const s = DB.getStats();
        const set = (id, value) => { const n = $(id); if (n) n.textContent = value; };
        set('totalRecords', s.total);
        set('weeklyRecords', s.weekly);
        set('activeUsers', s.users);
        set('storageUsed', formatSize(s.bytes));
    }

    /* ---------- index: recent records ---------- */

    function renderRecent(records) {
        const list = $('recentList');
        if (!list) return;
        clear(list);
        $('recentEmpty').style.display = records.length ? 'none' : '';

        records.slice(0, 5).forEach((r) => {
            const li = el('li');
            const icon = el('i', 'fa-solid fa-file-lines');
            const text = el('span', '', r.title);
            const meta = el('small', '', r.category + ' · ' + timeAgo(r.createdAt));
            li.append(icon, text, meta);
            list.appendChild(li);
        });
    }

    /* ---------- dashboard: weekly chart, categories, activity ---------- */

    function renderWeekChart(records) {
        const svg = $('activityChart');
        if (!svg) return;

        const W = Math.max(svg.clientWidth || 600, 320);
        const padL = 36, padR = 12;
        svg.setAttribute('viewBox', '0 0 ' + W + ' 260');
        svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
        clear(svg);

        const today = startOfDay(new Date());
        const days = [];
        for (let i = 6; i >= 0; i--) days.push(new Date(today.getTime() - i * DAY));
        const counts = days.map((day) => records.filter((r) => {
            const t = new Date(r.createdAt).getTime();
            return t >= day.getTime() && t < day.getTime() + DAY;
        }).length);

        const step = Math.max(1, Math.ceil(Math.max.apply(null, counts) / 3));
        const top = step * 3;

        [0, 1, 2, 3].forEach((n) => {
            const y = 200 - n * 60;
            svg.appendChild(svgEl('line', { 'class': 'grid-line', x1: padL, y1: y, x2: W - padR, y2: y }));
            svg.appendChild(svgEl('text', { x: padL - 8, y: y + 4, 'text-anchor': 'end' }, String(n * step)));
        });

        const slot = (W - padL - padR) / 7;
        const barW = Math.min(36, slot * 0.55);
        counts.forEach((count, i) => {
            const x = padL + slot * i + (slot - barW) / 2;
            const h = (count / top) * 180;
            if (count > 0) {
                svg.appendChild(svgEl('rect', { x: x, y: 200 - h, width: barW, height: h, rx: 6, fill: '#b6f05a' }));
            }
            svg.appendChild(svgEl('text', { x: x + barW / 2, y: 242, 'text-anchor': 'middle' },
                days[i].toLocaleDateString(undefined, { weekday: 'short' })));
        });

        if (!Math.max.apply(null, counts)) {
            svg.appendChild(svgEl('text', { 'class': 'empty-note', x: W / 2, y: 115 }, 'No activity yet'));
        }
    }

    function renderDashboardCategories(records) {
        const list = $('categoryList');
        if (!list) return;
        clear(list);
        const cats = countByCategory(records).slice(0, 6);
        $('categoryEmpty').style.display = cats.length ? 'none' : '';

        cats.forEach((c) => {
            const share = Math.round((c.count / records.length) * 100);
            const row = el('div', 'category-row');
            const bar = el('div', 'category-bar');
            const fill = el('i');
            fill.style.width = share + '%';
            bar.appendChild(fill);
            row.append(el('span', '', c.name), el('span', '', c.count + ' · ' + share + '%'), bar);
            list.appendChild(row);
        });
    }

    function renderActivity() {
        const list = $('activityList');
        if (!list) return;
        clear(list);
        const items = DB.getActivity(6);
        $('activityEmpty').style.display = items.length ? 'none' : '';

        const icons = { added: 'fa-plus', updated: 'fa-pen', deleted: 'fa-trash' };
        items.forEach((a) => {
            const li = el('li');
            const icon = el('i', 'fa-solid ' + (icons[a.action] || 'fa-circle'));
            const text = el('span', '', a.action.charAt(0).toUpperCase() + a.action.slice(1) + ': ' + a.title);
            li.append(icon, text, el('small', '', timeAgo(a.at)));
            list.appendChild(li);
        });
    }

    /* ---------- records page ---------- */

    function fillCategoryControls() {
        const filter = $('categoryFilter');
        const options = $('categoryOptions');
        if (!filter) return;
        const cats = DB.getCategories();

        clear(filter);
        const all = el('option', '', 'All categories');
        all.value = '';
        filter.appendChild(all);
        cats.forEach((name) => {
            const o = el('option', '', name);
            o.value = name;
            filter.appendChild(o);
        });
        if (!cats.includes(state.category)) state.category = '';
        filter.value = state.category;

        clear(options);
        cats.forEach((name) => {
            const o = document.createElement('option');
            o.value = name;
            options.appendChild(o);
        });
    }

    function matches(r) {
        const q = state.search.toLowerCase();
        const text = (r.title + ' ' + r.category + ' ' + r.notes).toLowerCase();
        return (!q || text.includes(q)) && (!state.category || r.category === state.category);
    }

    function actionButton(label, icon, className, onClick) {
        const btn = el('button', 'icon-button ' + className);
        btn.type = 'button';
        btn.setAttribute('aria-label', label);
        btn.appendChild(el('i', 'fa-solid ' + icon));
        btn.addEventListener('click', onClick);
        return btn;
    }

    function renderRecordsTable(records) {
        const body = $('recordsBody');
        if (!body) return;
        clear(body);

        const rows = records.filter(matches);
        const wrap = body.closest('.data-table-wrap');
        const empty = $('recordsEmpty');
        const hasAny = records.length > 0;

        wrap.style.display = rows.length ? '' : 'none';
        empty.style.display = rows.length ? 'none' : '';
        empty.querySelector('h3').textContent = hasAny ? 'No matching records' : 'No records yet';
        empty.querySelector('p').textContent = hasAny
            ? 'Try a different search or category.'
            : 'Your workspace is ready. Add your first record to get started.';
        $('emptyAddButton').style.display = hasAny ? 'none' : '';
        $('recordsCount').textContent = rows.length + (rows.length === 1 ? ' record' : ' records') +
            (hasAny && rows.length !== records.length ? ' of ' + records.length : '');

        rows.forEach((r) => {
            const tr = document.createElement('tr');
            const notes = r.notes.length > 60 ? r.notes.slice(0, 60) + '…' : r.notes;
            [r.title, r.category, notes || '—', formatDate(r.createdAt)].forEach((text) => {
                tr.appendChild(el('td', '', text));
            });
            const actions = el('div', 'row-actions');
            actions.append(
                actionButton('Edit ' + r.title, 'fa-pen', '', () => openDialog(r)),
                actionButton('Delete ' + r.title, 'fa-trash', 'danger', () => {
                    if (window.confirm('Delete "' + r.title + '"? This cannot be undone.')) {
                        DB.deleteRecord(r.id);
                        renderAll();
                    }
                })
            );
            const td = document.createElement('td');
            td.appendChild(actions);
            tr.appendChild(td);
            body.appendChild(tr);
        });
    }

    function openDialog(record) {
        const dialog = $('recordDialog');
        state.editingId = record ? record.id : null;
        $('dialogTitle').textContent = record ? 'Edit record' : 'Add record';
        $('saveRecord').textContent = record ? 'Save changes' : 'Save record';
        $('recordTitle').value = record ? record.title : '';
        $('recordCategory').value = record ? record.category : '';
        $('recordNotes').value = record ? record.notes : '';
        dialog.showModal();
        $('recordTitle').focus();
    }

    function initRecordsPage() {
        if (!$('recordsBody')) return;
        const dialog = $('recordDialog');

        $('searchInput').addEventListener('input', (e) => { state.search = e.target.value.trim(); renderAll(); });
        $('categoryFilter').addEventListener('change', (e) => { state.category = e.target.value; renderAll(); });
        $('addRecordButton').addEventListener('click', () => openDialog(null));
        $('emptyAddButton').addEventListener('click', () => openDialog(null));
        $('cancelRecord').addEventListener('click', () => dialog.close());
        dialog.addEventListener('click', (e) => { if (e.target === dialog) dialog.close(); });

        $('recordForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const data = {
                title: $('recordTitle').value,
                category: $('recordCategory').value,
                notes: $('recordNotes').value
            };
            const saved = state.editingId ? DB.updateRecord(state.editingId, data) : DB.addRecord(data);
            if (!saved) {
                window.alert('The record could not be saved. Check that the title and category are filled in and that browser storage is available.');
                return;
            }
            dialog.close();
            renderAll();
        });
    }

    /* ---------- render everything on the current page ---------- */

    function renderAll() {
        const records = DB.getRecords();
        renderStats();
        renderRecent(records);
        renderWeekChart(records);
        renderDashboardCategories(records);
        renderActivity();
        fillCategoryControls();
        renderRecordsTable(records);
    }

    function init() {
        if (!DB) return;
        initRecordsPage();
        renderAll();

        let timer;
        window.addEventListener('resize', () => {
            clearTimeout(timer);
            timer = setTimeout(() => renderWeekChart(DB.getRecords()), 150);
        });
        window.addEventListener('storage', renderAll);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
