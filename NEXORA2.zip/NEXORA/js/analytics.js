/* NEXORA · analytics.js
 * Powers analytics.html: range tabs, KPI cards, growth chart,
 * category breakdown, top-categories table, insights and CSV export.
 *
 * Data source: window.NexoraDB.getRecords() if database.js provides it,
 * otherwise records saved in localStorage under "nexora_records".
 * A record looks like: { id, title, category, notes, createdAt }
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'nexora_records';
    var SVG_NS = 'http://www.w3.org/2000/svg';
    var DAY = 24 * 60 * 60 * 1000;

    var state = { range: '7', records: [] };

    /* ---------- helpers ---------- */

    function $(id) { return document.getElementById(id); }

    function startOfDay(d) {
        return new Date(d.getFullYear(), d.getMonth(), d.getDate());
    }

    function formatDate(d) {
        return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
    }

    function formatSize(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    }

    function percent(part, whole) {
        return whole ? Math.round((part / whole) * 100) : 0;
    }

    function clear(node) {
        while (node.firstChild) node.removeChild(node.firstChild);
    }

    function svgEl(name, attrs, text) {
        var el = document.createElementNS(SVG_NS, name);
        Object.keys(attrs || {}).forEach(function (k) { el.setAttribute(k, attrs[k]); });
        if (text !== undefined) el.textContent = text;
        return el;
    }

    /* ---------- data ---------- */

    function loadRecords() {
        var raw = [];
        try {
            if (window.NexoraDB && typeof window.NexoraDB.getRecords === 'function') {
                raw = window.NexoraDB.getRecords();
            } else {
                var saved = localStorage.getItem(STORAGE_KEY);
                raw = saved ? JSON.parse(saved) : [];
            }
        } catch (e) {
            raw = [];
        }
        if (!Array.isArray(raw)) raw = [];

        return raw.map(function (r) {
            var date = r && r.createdAt ? new Date(r.createdAt) : null;
            if (date && isNaN(date.getTime())) date = null;
            return {
                title: String((r && r.title) || ''),
                category: String((r && r.category) || '').trim() || 'Uncategorized',
                notes: String((r && r.notes) || ''),
                date: date,
                raw: r
            };
        });
    }

    function rangeStart() {
        if (state.range === 'all') return null;
        var days = parseInt(state.range, 10);
        return new Date(startOfDay(new Date()).getTime() - (days - 1) * DAY);
    }

    function inRange(records) {
        var from = rangeStart();
        if (!from) return records;
        return records.filter(function (r) { return r.date && r.date >= from; });
    }

    function countByCategory(records) {
        var map = {};
        records.forEach(function (r) { map[r.category] = (map[r.category] || 0) + 1; });
        return Object.keys(map)
            .map(function (name) { return { name: name, count: map[name] }; })
            .sort(function (a, b) { return b.count - a.count || a.name.localeCompare(b.name); });
    }

    /* ---------- KPI cards ---------- */

    function renderKpis(all, ranged) {
        $('kpiTotal').textContent = all.length;
        $('kpiAdded').textContent = ranged.length;
        $('kpiCategories').textContent = countByCategory(all).length;
        var json = JSON.stringify(all.map(function (r) { return r.raw; }));
        $('kpiStorage').textContent = formatSize(new Blob([json]).size);
    }

    /* ---------- growth chart ---------- */

    function renderChart(all) {
        var svg = $('growthChart');
        var W = Math.max(svg.clientWidth || 600, 320);
        var H = 260, padL = 44, padR = 16;
        svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
        svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
        clear(svg);

        var dated = all.filter(function (r) { return r.date; });
        var today = startOfDay(new Date());
        var start = rangeStart();
        if (!start) {
            start = dated.length
                ? startOfDay(new Date(Math.min.apply(null, dated.map(function (r) { return r.date.getTime(); }))))
                : today;
        }

        var span = Math.max(1, Math.round((today - start) / DAY) + 1);
        var bucket = Math.max(1, Math.ceil(span / 30));
        var points = [];
        for (var i = 0; i < span; i += bucket) {
            var end = new Date(Math.min(start.getTime() + (i + bucket) * DAY, today.getTime() + DAY));
            var total = dated.filter(function (r) { return r.date < end; }).length;
            points.push({ total: total, label: new Date(end.getTime() - DAY) });
        }

        var maxVal = Math.max.apply(null, points.map(function (p) { return p.total; }));
        var step = Math.max(1, Math.ceil(maxVal / 3));
        var top = step * 3;
        var yFor = function (v) { return 200 - (v / top) * 180; };

        [0, 1, 2, 3].forEach(function (n) {
            var y = 200 - n * 60;
            svg.appendChild(svgEl('line', { 'class': 'grid-line', x1: padL, y1: y, x2: W - padR, y2: y }));
            svg.appendChild(svgEl('text', { x: padL - 8, y: y + 4, 'text-anchor': 'end' }, String(n * step)));
        });

        if (!dated.length) {
            svg.appendChild(svgEl('text', { 'class': 'empty-note', x: W / 2, y: 115 }, 'No data to chart yet'));
            return;
        }

        var xFor = function (idx) {
            if (points.length === 1) return (padL + W - padR) / 2;
            return padL + (idx / (points.length - 1)) * (W - padL - padR);
        };

        var coords = points.map(function (p, idx) { return xFor(idx) + ',' + yFor(p.total); });
        if (points.length > 1) {
            svg.appendChild(svgEl('polygon', {
                points: xFor(0) + ',200 ' + coords.join(' ') + ' ' + xFor(points.length - 1) + ',200',
                fill: 'rgba(182, 240, 90, 0.12)'
            }));
            svg.appendChild(svgEl('polyline', {
                points: coords.join(' '), fill: 'none', stroke: '#b6f05a',
                'stroke-width': 2.5, 'stroke-linejoin': 'round', 'stroke-linecap': 'round'
            }));
        }
        svg.appendChild(svgEl('circle', {
            cx: xFor(points.length - 1), cy: yFor(points[points.length - 1].total), r: 4.5, fill: '#b6f05a'
        }));

        var labelIdx = points.length === 1 ? [0] : [0, Math.floor((points.length - 1) / 2), points.length - 1];
        labelIdx.forEach(function (idx, n) {
            var anchor = labelIdx.length === 1 ? 'middle' : (n === 0 ? 'start' : (n === labelIdx.length - 1 ? 'end' : 'middle'));
            svg.appendChild(svgEl('text', { x: xFor(idx), y: 242, 'text-anchor': anchor }, formatDate(points[idx].label)));
        });
    }

    /* ---------- category breakdown + table ---------- */

    function renderCategories(ranged) {
        var cats = countByCategory(ranged);
        var list = $('categoryList');
        var body = $('categoryTable');
        var wrap = body.closest('.data-table-wrap');
        clear(list);
        clear(body);

        $('categoryEmpty').style.display = cats.length ? 'none' : '';
        $('tableEmpty').style.display = cats.length ? 'none' : '';
        wrap.style.display = cats.length ? '' : 'none';

        cats.forEach(function (c) {
            var share = percent(c.count, ranged.length);

            var row = document.createElement('div');
            row.className = 'category-row';
            var name = document.createElement('span');
            name.textContent = c.name;
            var value = document.createElement('span');
            value.textContent = c.count + ' · ' + share + '%';
            var bar = document.createElement('div');
            bar.className = 'category-bar';
            var fill = document.createElement('i');
            fill.style.width = share + '%';
            bar.appendChild(fill);
            row.appendChild(name);
            row.appendChild(value);
            row.appendChild(bar);
            list.appendChild(row);

            var tr = document.createElement('tr');
            [c.name, String(c.count), share + '%'].forEach(function (text) {
                var td = document.createElement('td');
                td.textContent = text;
                tr.appendChild(td);
            });
            body.appendChild(tr);
        });
    }

    /* ---------- insights ---------- */

    function addInsight(container, text) {
        var box = document.createElement('div');
        box.className = 'insight';
        var icon = document.createElement('i');
        icon.className = 'fa-solid fa-lightbulb';
        var span = document.createElement('span');
        span.textContent = text;
        box.appendChild(icon);
        box.appendChild(span);
        container.appendChild(box);
    }

    function rangeLabel() {
        return state.range === 'all' ? 'all time' : 'the last ' + state.range + ' days';
    }

    function renderInsights(all, ranged) {
        var box = $('insightList');
        clear(box);

        if (!all.length) {
            addInsight(box, 'Insights will appear here once your workspace has records to analyze.');
            return;
        }

        addInsight(box, 'Your workspace holds ' + all.length + (all.length === 1 ? ' record' : ' records') +
            ' across ' + countByCategory(all).length + (countByCategory(all).length === 1 ? ' category.' : ' categories.'));

        if (!ranged.length) {
            addInsight(box, 'No records were added in ' + rangeLabel() + '.');
            return;
        }

        addInsight(box, ranged.length + (ranged.length === 1 ? ' record was' : ' records were') +
            ' added in ' + rangeLabel() + '.');

        var top = countByCategory(ranged)[0];
        addInsight(box, '"' + top.name + '" is the largest category in ' + rangeLabel() + ', with ' +
            top.count + ' of ' + ranged.length + ' records (' + percent(top.count, ranged.length) + '%).');
    }

    /* ---------- CSV export ---------- */

    function csvCell(value) {
        var text = String(value == null ? '' : value);
        if (/^[=+\-@\t\r]/.test(text)) text = "'" + text;
        return '"' + text.replace(/"/g, '""') + '"';
    }

    function exportReport() {
        var ranged = inRange(state.records);
        var rows = [['Title', 'Category', 'Notes', 'Added']].concat(ranged.map(function (r) {
            return [r.title, r.category, r.notes, r.date ? r.date.toISOString() : ''];
        }));
        var csv = rows.map(function (row) { return row.map(csvCell).join(','); }).join('\r\n');

        var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var link = document.createElement('a');
        link.href = url;
        link.download = 'nexora-report-' + new Date().toISOString().slice(0, 10) + '.csv';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }

    /* ---------- render + events ---------- */

    function render() {
        state.records = loadRecords();
        var ranged = inRange(state.records);
        renderKpis(state.records, ranged);
        renderChart(state.records);
        renderCategories(ranged);
        renderInsights(state.records, ranged);
    }

    function init() {
        var tabs = document.querySelectorAll('.range-tabs button');
        tabs.forEach(function (btn) {
            btn.addEventListener('click', function () {
                tabs.forEach(function (b) { b.classList.remove('active'); });
                btn.classList.add('active');
                state.range = btn.getAttribute('data-range');
                render();
            });
        });

        $('exportButton').addEventListener('click', exportReport);

        var timer;
        window.addEventListener('resize', function () {
            clearTimeout(timer);
            timer = setTimeout(function () { renderChart(state.records); }, 150);
        });
        window.addEventListener('storage', render);

        render();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
