# NEXORA: Installation

NEXORA is a static website. There is nothing to compile or install.

## Run it locally

1. Download or clone the project and unzip it.
2. Open `index.html` in a modern web browser.

### Optional: use a local server

If you prefer to serve the files over HTTP, run this from the project folder (requires Python 3):

```
python3 -m http.server 8000
```

Then open `http://localhost:8000` in your browser.

## Things to know

- Data is saved in your browser's `localStorage`. It stays on your device and is not shared between browsers or devices.
- Clearing your browser's site data for NEXORA also erases your records.
- The icons and font load from a CDN, so an internet connection is needed for them to appear.

## Hosting

Because NEXORA is a static site, you can host the folder on any static hosting service, such as GitHub Pages.
