# NEXORA: Project Overview

NEXORA is a modern data management platform designed to simplify database organization, record management, information retrieval and business analytics through an intuitive interface.

Built with modern web technologies, NEXORA explores practical approaches to data management, visualization and digital business operations.

## Pages

| Page | File | Purpose |
| --- | --- | --- |
| Overview | `index.html` | Welcome screen, summary cards and the five most recent records |
| Dashboard | `dashboard.html` | Summary cards, 7-day activity chart, top categories and recent activity |
| Data Records | `records.html` | Add, edit, delete, search and filter records |
| Analytics | `analytics.html` | Date-range analytics, growth chart, category breakdown, insights and CSV export |

## Folder structure

```
NEXORA/
├── index.html
├── dashboard.html
├── records.html
├── analytics.html
├── README.md
├── css/
│   ├── style.css        base, layout, sidebar, buttons, tables, forms
│   └── dashboard.css    page content: banner, cards, panels, charts
├── js/
│   ├── database.js      data layer (window.NexoraDB, localStorage)
│   ├── app.js           index, dashboard and records pages
│   └── analytics.js     analytics page
├── assets/
│   ├── icons/           favicon.svg, logo.svg
│   └── images/          hero-pattern.svg, empty-state.svg
└── documents/           project documentation
```

## Technology

- HTML, CSS and JavaScript only. No framework and no build step.
- Data is stored in the browser with `localStorage`. There is no server or account system.
- Icons come from Font Awesome and the Manrope font from Google Fonts, both loaded from a CDN, so an internet connection is needed for them to appear.
