# NEXORA: Features

## Data Records
- Add, edit and delete records (title, category and optional notes).
- Search across title, category and notes.
- Filter by category.
- A confirmation prompt appears before a record is deleted.
- Records are listed newest first.

## Overview and Dashboard
- Summary cards: total records, records added in the last 7 days, users and storage used.
- Overview page: the five most recent records.
- Dashboard: a 7-day activity chart, the top six categories and the latest activity (records added, updated or deleted).

## Analytics
- Date ranges: 7 days, 30 days, 90 days and all time.
- Summary cards, a records-over-time chart, a category breakdown and a ranked categories table.
- Plain-language insights generated from your own records.
- Export the selected range as a CSV report.

## Interface
- Dark theme with a sidebar layout.
- Responsive: on screens under 900 px wide the sidebar becomes a bottom tab bar.
- Friendly empty states on every page until data is added.

## Not built yet
- The Team Members, Activity Logs and Settings links in the sidebar are placeholders.
- The search and notification buttons in the top bar are visual only.
- There is no sign-in. The workspace has a single user, the Administrator.
