# NEXORA: Database Structure

NEXORA stores its data in the browser's `localStorage`. The data layer is `js/database.js`, which exposes a global object called `NexoraDB`.

## Storage keys

| Key | Contents |
| --- | --- |
| `nexora_records` | Array of records |
| `nexora_activity` | Array of activity entries (latest 50 are kept) |
| `nexora_users` | Array of users. If empty, one default Administrator is used |

## Record

```json
{
  "id": "rec_...",
  "title": "string, required, up to 120 characters",
  "category": "string, required, up to 40 characters",
  "notes": "string, optional, up to 500 characters",
  "createdAt": "ISO 8601 date-time",
  "updatedAt": "ISO 8601 date-time, or null if never edited"
}
```

## Activity entry

```json
{
  "id": "act_...",
  "action": "added | updated | deleted",
  "title": "title of the record",
  "at": "ISO 8601 date-time"
}
```

## User

```json
{ "id": "usr_admin", "name": "Administrator", "role": "Workspace Owner" }
```

## NexoraDB methods

| Method | Description |
| --- | --- |
| `getRecords()` | All records, newest first |
| `addRecord({ title, category, notes })` | Saves a record and returns it, or `null` if invalid |
| `updateRecord(id, { title, category, notes })` | Updates a record and returns it, or `null` |
| `deleteRecord(id)` | Removes a record and returns `true` if it existed |
| `getCategories()` | Sorted list of distinct category names |
| `getUsers()` | Workspace users |
| `getActivity(limit)` | Latest activity entries, newest first |
| `getStats()` | `{ total, weekly, users, bytes }` for the summary cards |
| `clearAll()` | Removes all records and activity |

## Limits

Browsers cap `localStorage` at a few megabytes per site, so this approach suits small to medium amounts of data.
